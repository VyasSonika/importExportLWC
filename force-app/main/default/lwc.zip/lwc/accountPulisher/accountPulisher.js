import { LightningElement } from 'lwc';

export default class AccountPulisher extends LightningElement {}